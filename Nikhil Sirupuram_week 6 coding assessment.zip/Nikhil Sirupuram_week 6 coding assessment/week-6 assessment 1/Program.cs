﻿using CodingA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory_Management
{
    internal class demo
    {
        static void Main(string[] args)
        {
          /* Demo.InsertCategory(5, "samsung", 35000, 10);
            Console.WriteLine(); */

            /*Demo.Getprodinfo();
            Console.WriteLine(); */

            Demo.UpdatePrice(5, "vivo", 55340, 20);
            Console.WriteLine(); 
        }
    }
}