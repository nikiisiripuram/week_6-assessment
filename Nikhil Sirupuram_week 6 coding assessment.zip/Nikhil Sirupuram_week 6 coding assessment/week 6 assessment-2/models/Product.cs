﻿namespace e_commerce.models
{
    public class Class
    {
    }
}
